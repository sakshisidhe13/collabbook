const Loader = () => {
  return (
    <div>
      <span className="loading loading-bars loading-xl"></span>
    </div>
  );
};
export default Loader;
